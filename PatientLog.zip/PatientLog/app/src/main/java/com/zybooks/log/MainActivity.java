package com.zybooks.log;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText mNameEditText;
    private EditText mAgeEditText;
    private RadioGroup mSexRadioGroup;
    private EditText mMedicalHistoryEditText;
    private EditText mPatientIdEditText;
    private PatientDatabase mPatientDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_patient);

        mNameEditText = findViewById(R.id.edit_text_name);
        mAgeEditText = findViewById(R.id.edit_text_age);
        mSexRadioGroup = findViewById(R.id.radio_group_sex);
        mMedicalHistoryEditText = findViewById(R.id.edit_text_medical_history);
        mPatientIdEditText = findViewById(R.id.edit_text_patient_id);
        mPatientDb = PatientDatabase.getInstance(this);


        Button addPatientButton = findViewById(R.id.button_add_patient);
        addPatientButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addPatient();
            }
        });

        Button viewPatientButton = findViewById(R.id.button_view_patient);
        viewPatientButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewPatient();
            }
        });
    }

    private void addPatient() {
        String name = mNameEditText.getText().toString().trim();
        String ageStr = mAgeEditText.getText().toString().trim();
        int age = 0;
        try {
            age = Integer.parseInt(ageStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid age", Toast.LENGTH_SHORT).show();
            return;
        }

        int checkedRadioButtonId = mSexRadioGroup.getCheckedRadioButtonId();
        if (checkedRadioButtonId == -1) {
            Toast.makeText(this, "Please select a gender", Toast.LENGTH_SHORT).show();
            return;
        }
        RadioButton sexRadioButton = findViewById(checkedRadioButtonId);
        String sex = sexRadioButton.getText().toString();

        String medicalHistory = mMedicalHistoryEditText.getText().toString().trim();

        if (name.isEmpty() || ageStr.isEmpty() || medicalHistory.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        Patient patient = new Patient(name, age, sex, medicalHistory);

        long result = mPatientDb.patientDao().addPatient(patient);

        if (result == -1) {
            Toast.makeText(this, "Failed to add patient", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Patient added successfully", Toast.LENGTH_SHORT).show();
            mNameEditText.setText("");
            mAgeEditText.setText("");
            mSexRadioGroup.clearCheck();
            mMedicalHistoryEditText.setText("");
        }
    }

    private void viewPatient() {
        String patientIdStr = mPatientIdEditText.getText().toString().trim();
        if (patientIdStr.isEmpty()) {
            Toast.makeText(this, "Please enter a patient ID", Toast.LENGTH_SHORT).show();
            return;
        }

        long patientId = Long.parseLong(patientIdStr);

        Intent intent = new Intent(this, ViewPatientActivity.class);
        intent.putExtra(ViewPatientActivity.EXTRA_PATIENT_ID, patientId);
        startActivity(intent);
    }
}
