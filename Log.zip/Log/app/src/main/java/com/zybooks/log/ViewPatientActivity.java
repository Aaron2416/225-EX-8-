package com.zybooks.log;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class ViewPatientActivity extends AppCompatActivity {

    public static final String EXTRA_PATIENT_ID = "com.zybooks.log.EXTRA_PATIENT_ID";

    private TextView mNameTextView;
    private TextView mAgeTextView;
    private RadioButton mSexMaleRadioButton;
    private RadioButton mSexFemaleRadioButton;
    private TextView mMedicalHistoryTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_patient);

        mNameTextView = findViewById(R.id.edit_text_name);
        mAgeTextView = findViewById(R.id.edit_text_age);
        mSexMaleRadioButton = findViewById(R.id.radio_button_male);
        mSexFemaleRadioButton = findViewById(R.id.radio_button_female);
        mMedicalHistoryTextView = findViewById(R.id.edit_text_medical_history);

        long patientId = getIntent().getLongExtra(EXTRA_PATIENT_ID, -1);

        if (patientId == -1) {
            Toast.makeText(this, "Patient ID not found", Toast.LENGTH_SHORT).show();
            finish();
        }

        PatientDatabase patientDb = PatientDatabase.getInstance(this);
        Patient patient = patientDb.getPatient(patientId);

        if (patient == null) {
            Toast.makeText(this, "Patient not found", Toast.LENGTH_SHORT).show();
            finish();
        }

        mNameTextView.setText(patient.getName());
        mAgeTextView.setText(String.valueOf(patient.getAge()));
        if (patient.getSex().equals("Male")) {
            mSexMaleRadioButton.setChecked(true);
        } else {
            mSexFemaleRadioButton.setChecked(true);
        }
        mMedicalHistoryTextView.setText(patient.getMedicalHistory());
    }
}
